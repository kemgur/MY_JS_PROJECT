import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
    <div>
        <h1>My To Do List</h1>
        <ul>
            <li>Go Shopping</li>
            <li>Do Exercise</li>
            <li>Reserve Hotel</li>
        </ul>
    </div>
,
document.getElementById("root"));