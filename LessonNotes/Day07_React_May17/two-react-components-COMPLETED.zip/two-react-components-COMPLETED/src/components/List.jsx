import React from 'react';

function List(){
    return <ul>
    <li>Go Shopping</li>
    <li>Do Exercise</li>
    <li>Reserve Hotel</li>
</ul>
}

export default List;