// THIS COMPONENT WILL HAVE HEADING RELATED CODES
//1. import React 
import React from 'react';

//2. add component
//Create heading component.
//Name of this component is Heading
function Heading(){
    return <h1>My To Do List</h1>
}

//3. I must export so I can use Heading in other files
export default Heading;